/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package system.software_engineering;

/**
 *
 * @author addie
 */
public class variable {
    
    public static String firstName;
    public static String surname;
    public static String gender;
    public static String age;
    public static String address;
    public static String contactNo;
    public static String relationship;
    public static String dateOfVisit;
    public static String inmateFname;
    public static String middleName;
    public static String inmateSurname;
    
    public static String adminUsername;
    public static String adminPassword;
}

